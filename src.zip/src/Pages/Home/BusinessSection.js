import React from "react";

const BusinessSection = () => {
  return <div></div>;
};

export default BusinessSection;
